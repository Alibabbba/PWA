# Invoice

## Run

npm i
npm run build
npm run preview

database
npm run db
